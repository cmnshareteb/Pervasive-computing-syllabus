package com.example.admin.swyh;

import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mp;
    String url;
    Button btnstart = (Button) findViewById(R.id.btnstart);
    EditText etUrl = (EditText) findViewById(R.id.etUrl);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnstart.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                url = etUrl.getText().toString();

                mp=new MediaPlayer();

                try{
                    // deprecated mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                   //mp.setDataSource(getApplicationContext(),url);  //use this if it fails.
                    mp.setDataSource(url);
                    mp.prepareAsync();
                }catch(Exception e)
                {
                    e.printStackTrace();
                }

                mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mediaPlayer, int i, int i1) {
                        mediaPlayer.reset();
                        return false;
                    }
                });
                mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        mp.start();
                    }
                });

            }
        });



    }

    protected void onDestroy()
    {
        super.onDestroy();
        if (mp!=null){
            if (mp.isPlaying()){
                mp.stop();
            }
            mp.release();
            mp = null;
        }
    }
}
